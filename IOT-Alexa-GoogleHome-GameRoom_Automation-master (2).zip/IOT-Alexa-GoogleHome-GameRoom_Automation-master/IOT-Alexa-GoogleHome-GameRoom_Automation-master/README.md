# IOT-Alexa-GoogleHome-GameRoom_Automation (In-Progress)

YouTube Tutorial -->https://www.youtube.com/watch?v=1X6FeuUiMUY

Alexa skills to control ESP8266 without opening a router's port/firewal.


In This project you will be able to control You TV with Alexa & Google Home.

1. Download this project and unzip.

2. Deploy this project to Heroku by clicking this button
    [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

3. Copy following folders to "C:\Program Files (x86)\Arduino\libraries"

    arduinoWebSockets

    ArduinoJson
    
    IRremoteESP8266

4. Connect, Capture, Update and flash your NodeMcu sketch

5. Create IFTTT templates and add Heroku app URL as an end-point

6. Test and enjoy.
